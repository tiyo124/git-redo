#!/bin/bash/
#
#testing env variables
echo "this will display your user info : $user"
echo "this is userid: $uid"
echo "this is the home directory : $home"
